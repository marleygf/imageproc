CISC/CMPE 457 Assignment 1

Marley Ferreira-Malyon 10149778 14mfm1
Bailey Crockett 10136512 13bac11
